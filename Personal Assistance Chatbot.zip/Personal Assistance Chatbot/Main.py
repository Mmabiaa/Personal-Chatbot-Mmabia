from GUI import ChatApp
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatApp(root)
    root.mainloop()