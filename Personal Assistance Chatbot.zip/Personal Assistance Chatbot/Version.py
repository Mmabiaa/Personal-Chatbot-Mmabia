import nltk 
print(nltk.__version__)